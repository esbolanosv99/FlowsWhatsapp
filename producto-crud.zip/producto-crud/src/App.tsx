import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from './app/store';
import { addProduct, deleteProduct, updateProduct } from './features/products/productsSlice';
import ProductCard from './components/ProductCard';
import CreateProductModal from './components/CreateProductModal';
import EditProductModal from './components/EditProductModal';
import Modal from './components/Modal';
import RepeatedProductsTable from './components/RepeatedProductsTable';
import './App.css';

interface Product {
  id: number;
  name: string;
  price: number;
  img: string;
  model: string;
  status: string;
}

interface RepeatedProduct {
  name: string;
  count: number;
}

const App: React.FC = () => {
  const products = useSelector((state: RootState) => state.products.products);
  const dispatch = useDispatch();
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState<'create' | 'edit' | 'repeated'>('create');
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);

  const topRepeatedNamesWithCount = (): RepeatedProduct[] => {
    const nameCount: { [key: string]: number } = {};

    products.forEach(product => {
      const normalizedName = product.name.trim().toLowerCase();
      nameCount[normalizedName] = (nameCount[normalizedName] || 0) + 1;
    });

    const sortedProducts = Object.entries(nameCount)
      .map(([name, count]) => ({ name: capitalize(name), count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return sortedProducts;
  };

  const capitalize = (str: string) => str.charAt(0).toUpperCase() + str.slice(1);

  const addProductHandler = (product: Product) => {
    dispatch(addProduct(product));
    setIsModalOpen(false);
  };

  const updateProductHandler = (product: Product) => {
    dispatch(updateProduct(product));
    setIsModalOpen(false);
  };

  const deleteProductHandler = (id: number) => {
    dispatch(deleteProduct(id));
  };

  const handleEditClick = (product: Product) => {
    setCurrentProduct(product);
    setIsModalOpen(true);
    setModalContent('edit');
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="app">
      <header className="app-header">
        <h1>CRUD PRODUCTOS - MARCAS DE CELULARES</h1>
      </header>

      <main>
        <div className="search-container">
          <i className="fas fa-search search-icon"></i>
          <input
            type="text"
            placeholder="Buscar por Marca"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
          <button onClick={() => { setIsModalOpen(true); setModalContent('repeated'); }} className="repeated-products-button">
            Productos más Repetidos
          </button>
        </div>

        <button onClick={() => { setIsModalOpen(true); setModalContent('create'); }} className="create-product-button">
          Crear Producto
        </button>

        <div className="product-list">
          {filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onDelete={() => deleteProductHandler(product.id)}
              onUpdate={() => handleEditClick(product)}
            />
          ))}
        </div>

        <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
          {modalContent === 'create' && <CreateProductModal onAdd={addProductHandler} onClose={() => setIsModalOpen(false)} />}
          {modalContent === 'edit' && currentProduct && (
            <EditProductModal
              product={currentProduct}
              onSave={updateProductHandler}
              onClose={() => setIsModalOpen(false)}
            />
          )}
          {modalContent === 'repeated' && <RepeatedProductsTable products={topRepeatedNamesWithCount()} />}
        </Modal>
      </main>

      <footer className="app-footer">
        <p>&copy; 2024 CRUD Productos - Todos los derechos reservados</p>
      </footer>
    </div>
  );
};

export default App;
