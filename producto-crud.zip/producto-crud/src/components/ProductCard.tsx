// src/components/ProductCard.tsx
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import './ProductCard.css';

interface Product {
  id: number;
  name: string;
  price: number;
  img: string;
  model: string;
  status: string;
}

interface ProductCardProps {
  product: Product;
  onDelete: () => void;
  onUpdate: () => void; // Cambiado de (product: Product) a () para ser llamado sin parámetros
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onDelete, onUpdate }) => {
  return (
    <div className="product-card">
      <img src={product.img || 'default-image-url.jpg'} alt={product.name} />
      <h3>{product.name}</h3>
      <p>{product.model}</p>
      <p className="price">${product.price.toFixed(2)}</p>
      <div className="actions">
        <button onClick={onUpdate}>
          <FontAwesomeIcon icon={faEdit} className="icon" />
        </button>
        <button onClick={onDelete}>
          <FontAwesomeIcon icon={faTrashAlt} className="icon" />
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
