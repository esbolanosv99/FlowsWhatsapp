import React from 'react';
import './RepeatedProductsTable.css';

interface RepeatedProduct {
  name: string;
  count: number;
}

interface RepeatedProductsTableProps {
  products: RepeatedProduct[];
}

const RepeatedProductsTable: React.FC<RepeatedProductsTableProps> = ({ products }) => {
  return (
    <div className="repeated-products-container">
      <h2>Top 5 Productos Más Repetidos</h2>
      {products.length > 0 ? (
        <table className="repeated-products-table">
          <thead>
            <tr>
              <th>Nombre del Producto</th>
              <th>Cantidad</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product, index) => (
              <tr key={index}>
                <td>{product.name}</td>
                <td>{product.count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No hay productos repetidos.</p>
      )}
    </div>
  );
};

export default RepeatedProductsTable;
