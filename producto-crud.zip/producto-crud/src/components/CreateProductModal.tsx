import React, { useState } from 'react';
import './CreateProductModal.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes } from '@fortawesome/free-solid-svg-icons';

interface CreateProductModalProps {
  onAdd: (product: Product) => void;
  onClose: () => void;
}

interface Product {
  id: number;
  name: string;
  price: number;
  img: string;
  model: string;
  status: string;
}

const CreateProductModal: React.FC<CreateProductModalProps> = ({ onAdd, onClose }) => {
  const [product, setProduct] = useState<Product>({
    id: Date.now(), // Simple ID generator, replace as needed
    name: '',
    price: 0,
    img: '',
    model: '',
    status: 'Available',
  });

  const handleSubmit = () => {
    onAdd(product);
    onClose(); // Close the modal after adding the product
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <button className="modal-close-button" onClick={onClose}>
          <FontAwesomeIcon icon={faTimes} />
        </button>
        <h2>Create Product</h2>
        <form className="create-product-form">
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input
              id="name"
              type="text"
              placeholder="Name"
              value={product.name}
              onChange={e => setProduct({ ...product, name: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label htmlFor="price">Price</label>
            <input
              id="price"
              type="number"
              placeholder="Price"
              value={product.price}
              onChange={e => setProduct({ ...product, price: +e.target.value })}
            />
          </div>
          <div className="form-group">
            <label htmlFor="img">Image URL</label>
            <input
              id="img"
              type="text"
              placeholder="Image URL"
              value={product.img}
              onChange={e => setProduct({ ...product, img: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label htmlFor="model">Model</label>
            <input
              id="model"
              type="text"
              placeholder="Model"
              value={product.model}
              onChange={e => setProduct({ ...product, model: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label htmlFor="status">Status</label>
            <select
              id="status"
              value={product.status}
              onChange={e => setProduct({ ...product, status: e.target.value })}
            >
              <option value="Available">Available</option>
              <option value="Unavailable">Unavailable</option>
            </select>
          </div>
          <div className="form-actions">
            <button type="button" onClick={handleSubmit} className="submit-button">Add Product</button>
            <button type="button" onClick={onClose} className="close-button">Close</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateProductModal;
