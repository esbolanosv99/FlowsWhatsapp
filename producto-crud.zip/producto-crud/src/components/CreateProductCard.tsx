import React, { useState } from 'react';
import './CreateProductCard.css';

interface Product {
  id: number;
  name: string;
  price: number;
  img: string;
  model: string;
  status: string;
}

interface CreateProductCardProps {
  onAdd: (product: Product) => void;
}

const CreateProductCard: React.FC<CreateProductCardProps> = ({ onAdd }) => {
  const [product, setProduct] = useState<Product>({
    id: Date.now(), // Puedes cambiar esto por una lógica más robusta para generar IDs únicos
    name: '',
    price: 0,
    img: '',
    model: '',
    status: 'Available'
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProduct({ ...product, [name]: value });
  };

  const handleSubmit = () => {
    onAdd(product);
    setProduct({
      id: Date.now(),
      name: '',
      price: 0,
      img: '',
      model: '',
      status: 'Available'
    });
  };

  return (
    <div className="create-product-card">
      <input
        type="text"
        name="name"
        value={product.name}
        onChange={handleChange}
        placeholder="Name"
      />
      <input
        type="number"
        name="price"
        value={product.price}
        onChange={handleChange}
        placeholder="Price"
      />
      <input
        type="text"
        name="img"
        value={product.img}
        onChange={handleChange}
        placeholder="Image URL"
      />
      <input
        type="text"
        name="model"
        value={product.model}
        onChange={handleChange}
        placeholder="Model"
      />
      <select
        name="status"
        value={product.status}
        onChange={handleChange}
      >
        <option value="Available">Available</option>
        <option value="Out of Stock">Out of Stock</option>
      </select>
      <button onClick={handleSubmit}>Add Product</button>
    </div>
  );
};

export default CreateProductCard;
