import React, { useState } from 'react';
import './EditProductModal.css';

interface Product {
  id: number;
  name: string;
  price: number;
  img: string;
  model: string;
  status: string;
}

interface EditProductModalProps {
  product: Product;
  onSave: (product: Product) => void;
  onClose: () => void;
}

const EditProductModal: React.FC<EditProductModalProps> = ({ product, onSave, onClose }) => {
  const [updatedProduct, setUpdatedProduct] = useState<Product>({ ...product });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setUpdatedProduct({ ...updatedProduct, [name]: value });
  };

  const handleSubmit = () => {
    onSave(updatedProduct);
  };

  return (
    <div className="edit-product-modal">
      <h2>Edit Product</h2>
      <div className="form-group">
        <label htmlFor="name">Name</label>
        <input
          type="text"
          id="name"
          name="name"
          value={updatedProduct.name}
          onChange={handleChange}
          disabled
        />
      </div>
      <div className="form-group">
        <label htmlFor="price">Price</label>
        <input
          type="number"
          id="price"
          name="price"
          value={updatedProduct.price}
          onChange={handleChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="img">Image URL</label>
        <input
          type="text"
          id="img"
          name="img"
          value={updatedProduct.img}
          onChange={handleChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="model">Model</label>
        <input
          type="text"
          id="model"
          name="model"
          value={updatedProduct.model}
          onChange={handleChange}
        />
      </div>
      <div className="form-group">
        <label htmlFor="status">Status</label>
        <select
          id="status"
          name="status"
          value={updatedProduct.status}
          onChange={handleChange}
        >
          <option value="Available">Available</option>
          <option value="Out of Stock">Out of Stock</option>
        </select>
      </div>
      <div className="form-actions">
        <button onClick={handleSubmit}>Save</button>
        <button onClick={onClose}>Cancel</button>
      </div>
    </div>
  );
};

export default EditProductModal;
