import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface Product {
  id: number;
  name: string;
  price: number;
  img: string;
  model: string;
  status: string;
}

interface ProductsState {
  products: Product[];
}

const initialState: ProductsState = {
  products: JSON.parse(localStorage.getItem('products') || '[]'),
};

const productsSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    addProduct: (state, action: PayloadAction<Product>) => {
      state.products.push(action.payload);
      localStorage.setItem('products', JSON.stringify(state.products));
    },
    updateProduct: (state, action: PayloadAction<Product>) => {
      const { id, price, img, model, status } = action.payload;
      const index = state.products.findIndex(p => p.id === id);
      if (index !== -1) {
        state.products[index] = {
          ...state.products[index],
          price,
          img,
          model,
          status
        };
        localStorage.setItem('products', JSON.stringify(state.products));
      }
    },
    deleteProduct: (state, action: PayloadAction<number>) => {
      state.products = state.products.filter(product => product.id !== action.payload);
      localStorage.setItem('products', JSON.stringify(state.products));
    }
  },
});

export const { addProduct, updateProduct, deleteProduct } = productsSlice.actions;
export default productsSlice.reducer;
